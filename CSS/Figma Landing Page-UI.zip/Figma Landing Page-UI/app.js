alert("Hi! Welcome to my website");
alert("This is the Landing page of Figma Design");

